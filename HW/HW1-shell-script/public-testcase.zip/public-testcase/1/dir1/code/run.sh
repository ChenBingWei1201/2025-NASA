#!/bin/bash

echo "Running tests..."
python3 judge.py
