secret_problem = {
    'title': 'Unfinish Problem', 'description': 'TBD',
    'time_limit': 4, 'memory_limit': 256, 'id': 3, 
    'solution': {
        'python': [s for s in "NOT_FLAG"], 
        'c': [s for s in "NOT_FLAG"], 
        'cpp': [s for s in "NOT_FLAG"]
        }
    }
