#include "out.h"



int _init(EVP_PKEY_CTX *ctx)

{
  int iVar1;
  
  iVar1 = __gmon_start__();
  return iVar1;
}



void FUN_00101020(void)

{
  (*(code *)(undefined *)0x0)();
  return;
}



void FUN_00101050(void)

{
  __cxa_finalize();
  return;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int puts(char *__s)

{
  int iVar1;
  
  iVar1 = puts(__s);
  return iVar1;
}



// WARNING: Unknown calling convention -- yet parameter storage is locked

int strcmp(char *__s1,char *__s2)

{
  int iVar1;
  
  iVar1 = strcmp(__s1,__s2);
  return iVar1;
}



void processEntry _start(undefined8 param_1,undefined8 param_2)

{
  undefined1 auStack_8 [8];
  
  __libc_start_main(main,param_2,&stack0x00000008,0,0,param_1,auStack_8);
  do {
                    // WARNING: Do nothing block with infinite loop
  } while( true );
}



// WARNING: Removing unreachable block (ram,0x001010c3)
// WARNING: Removing unreachable block (ram,0x001010cf)

void deregister_tm_clones(void)

{
  return;
}



// WARNING: Removing unreachable block (ram,0x00101104)
// WARNING: Removing unreachable block (ram,0x00101110)

void register_tm_clones(void)

{
  return;
}



void __do_global_dtors_aux(void)

{
  if (completed_0 != '\0') {
    return;
  }
  FUN_00101050(__dso_handle);
  deregister_tm_clones();
  completed_0 = 1;
  return;
}



void frame_dummy(void)

{
  register_tm_clones();
  return;
}



undefined8 main(int param_1,long param_2)

        {
          int iVar1;
          undefined8 uVar2;
          int local_c;
          
          if (param_1 == 2) {
            for (local_c = 0; local_c < flag_len; local_c = local_c + 1) {
              pattern[local_c] = pattern[local_c] ^ key[local_c % key_len];
            }
            iVar1 = strcmp(*(char **)(param_2 + 8),pattern);
            if (iVar1 == 0) {
              puts("Congratulations! You found the flag!");
            }
            else {
              puts("Haha! wrong >:)!!!!!!");
            }
            uVar2 = 0;
          }
          else {
            puts("Usage: ./chal.exe <flag>");
            uVar2 = 1;
          }
          return uVar2;
        }



void _fini(void)

{
  return;
}



